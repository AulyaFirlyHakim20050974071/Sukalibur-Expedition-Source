package com.example.uts2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    EditText NoResi;
    EditText NamaPengirim;
    EditText Penerima;
    EditText Alamat;
    Spinner Tujuan;
    EditText Berat;
    Button Daftar;
    Button Batal;
    RadioGroup radioGroup;
    RadioButton Kilat;
    RadioButton Regular;
    ArrayList<Integer> regularPrice = new ArrayList<>(Arrays.asList(20000, 75000, 75000, 100000, 50000, 50000, 60000, 40000, 65000));
    ArrayList<Integer> kilatPrice = new ArrayList<>(Arrays.asList(50000, 110000, 110000, 130000, 80000, 80000, 90000, 70000, 85000));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        NoResi = findViewById(R.id.NoResi);
        NamaPengirim = findViewById(R.id.NamaPengirim);
        Penerima = findViewById(R.id.Penerima);
        Alamat = findViewById(R.id.Alamat);
        Tujuan = findViewById(R.id.Tujuan);
        Berat = findViewById(R.id.Berat);
        radioGroup = findViewById(R.id.radioGroup);
        Regular = (RadioButton) findViewById(R.id.Regular);
        Kilat = (RadioButton) findViewById(R.id.Kilat);
        Daftar = (Button) findViewById(R.id.Daftar);
        Batal = (Button) findViewById(R.id.Batal);

        Daftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int totalPrice = 0;
                if (radioGroup.getCheckedRadioButtonId() == R.id.Regular) {
                    totalPrice = regularPrice.get(Tujuan.getSelectedItemPosition()) * Integer.parseInt(Berat.getText().toString());
                } else if (radioGroup.getCheckedRadioButtonId() == R.id.Kilat) {
                    totalPrice = kilatPrice.get(Tujuan.getSelectedItemPosition()) * Integer.parseInt(Berat.getText().toString());
                } else {
                    Toast.makeText(MainActivity.this, "Layanan belum di pilih", Toast.LENGTH_SHORT).show();
                }
                Intent intent = new Intent(MainActivity.this, HasilActivity.class);
                intent.putExtra("noresi", NoResi.getText().toString());
                intent.putExtra("pengirim", NamaPengirim.getText().toString());
                intent.putExtra("penerima", Penerima.getText().toString());
                intent.putExtra("alamat", Alamat.getText().toString());
                intent.putExtra("tujuan", Tujuan.getSelectedItem().toString());
                intent.putExtra("berat", Berat.getText().toString());
                intent.putExtra("layanan", radioGroup.getCheckedRadioButtonId() == R.id.Regular ? "Regular" : "Kilat");
                intent.putExtra("total", String.valueOf(totalPrice));
                startActivity(intent);
            }
        });

        Batal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }



}