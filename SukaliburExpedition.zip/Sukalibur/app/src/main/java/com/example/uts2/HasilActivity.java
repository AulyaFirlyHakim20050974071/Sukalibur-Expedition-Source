package com.example.uts2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HasilActivity extends AppCompatActivity {

    TextView resi,pengirim,penerima,alamat,tujuan,berat,layanan,total;
    Button selesai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil);
        resi = findViewById(R.id.hasilNoResi);
        pengirim = findViewById(R.id.hasilNamaPengirim);
        penerima = findViewById(R.id.hasilPenerima);
        alamat = findViewById(R.id.hasilAlamat);
        tujuan = findViewById(R.id.hasilTujuan);
        berat = findViewById(R.id.hasilBerat);
        layanan = findViewById(R.id.hasilLayanan);
        total = findViewById(R.id.totalBayar);
        selesai = findViewById(R.id.hasilSelesai);

        Intent intent = getIntent();
        resi.setText(String.format("No Resi %s", intent.getStringExtra("noresi")));
        pengirim.setText(String.format("Nama Pengirim %s", intent.getStringExtra("pengirim")));
        penerima.setText(String.format("Penerima %s", intent.getStringExtra("penerima")));;
        alamat.setText(String.format("Alamat %s", intent.getStringExtra("alamat")));
        tujuan.setText(String.format("Tujuan %s", intent.getStringExtra("tujuan")));
        berat.setText(String.format("Berat %s", intent.getStringExtra("berat")));
        layanan.setText(String.format("Layanan %s", intent.getStringExtra("layanan")));
        total.setText(String.format("Total %s", intent.getStringExtra("total")));

        selesai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}